import asyncio
import logging

from core.config import Config
from core.fetcher import Fetcher
from bot.filters import apply_filters
from bot.telegram_bot import TelegramBot
from server.server import run as run_server

import threading

logging.basicConfig(level=logging.INFO)

async def main():
    Config.validate()
    fetcher = Fetcher()
    bot = TelegramBot(Config.TELEGRAM_TOKEN, Config.TELEGRAM_CHANNEL)

    while True:
        logging.info("Fetching tokens...")
        tokens = await fetcher.fetch_all()
        filtered = apply_filters(tokens)
        logging.info(f"{len(filtered)} tokens passed filters.")

        for token in filtered:
            msg = f"*{token.get('baseToken', {}).get('name', 'Unknown')}* — Price: ${token.get('priceUsd', 'N/A')}"
            await bot.send_message(msg)

        await asyncio.sleep(Config.FETCH_INTERVAL)

if __name__ == "__main__":
    threading.Thread(target=run_server).start()
    asyncio.run(main())