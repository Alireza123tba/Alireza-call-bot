def apply_filters(tokens, min_volume=5000, min_growth=1.1, max_age_minutes=60):
    filtered = []
    for token in tokens:
        try:
            volume = float(token.get("volume", 0))
            price_change = float(token.get("priceChange", 1))
            age = int(token.get("ageMinutes", 999))
            market_cap = float(token.get("marketCap", 0))

            if (
                volume >= min_volume
                and price_change >= min_growth
                and age <= max_age_minutes
                and market_cap > 0
            ):
                filtered.append(token)
        except Exception:
            continue
    return filtered