import logging
from telegram import Bot
from telegram.constants import ParseMode

class TelegramBot:
    def __init__(self, token: str, channel: str):
        self.bot = Bot(token)
        self.channel = channel

    async def send_message(self, text: str):
        try:
            await self.bot.send_message(
                chat_id=self.channel,
                text=text,
                parse_mode=ParseMode.MARKDOWN
            )
        except Exception as e:
            logging.error(f"Error sending message to Telegram: {e}")