import aiohttp
import asyncio
import logging
from typing import List, Dict

HEADERS = {
    "User-Agent": "Mozilla/5.0"
}

class Fetcher:
    DEXSCREENER_URL = "https://api.dexscreener.com/latest/dex/pairs"
    MEVX_URL = "https://api.mevx.io/latest-pairs"

    def __init__(self, timeout: int = 10):
        self.timeout = timeout

    async def fetch_json(self, session: aiohttp.ClientSession, url: str) -> Dict:
        try:
            async with session.get(url, headers=HEADERS, timeout=self.timeout) as resp:
                resp.raise_for_status()
                return await resp.json()
        except Exception as e:
            logging.error(f"Error fetching {url}: {e}")
            return {}

    async def fetch_all(self) -> List[Dict]:
        async with aiohttp.ClientSession() as session:
            dex_data = await self.fetch_json(session, self.DEXSCREENER_URL)
            mevx_data = await self.fetch_json(session, self.MEVX_URL)

        combined = []
        if dex_data.get("pairs"):
            combined.extend(dex_data["pairs"])
        if mevx_data.get("data"):
            combined.extend(mevx_data["data"])

        return combined