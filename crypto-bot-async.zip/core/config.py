import os
from dotenv import load_dotenv

load_dotenv()

class ConfigError(Exception):
    pass

class Config:
    TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
    TELEGRAM_CHANNEL = os.getenv("TELEGRAM_CHANNEL")
    FETCH_INTERVAL = int(os.getenv("FETCH_INTERVAL", 180))

    @classmethod
    def validate(cls):
        missing = []
        if not cls.TELEGRAM_TOKEN:
            missing.append("TELEGRAM_TOKEN")
        if not cls.TELEGRAM_CHANNEL:
            missing.append("TELEGRAM_CHANNEL")
        if missing:
            raise ConfigError(f"Missing environment variables: {', '.join(missing)}")