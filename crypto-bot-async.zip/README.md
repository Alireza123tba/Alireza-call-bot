# Crypto Token Auto-Poster Bot (Async Version)

## Quick Start

1. Clone the repo & enter the folder
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Configure `.env` file (see `.env.example`)
4. Run the bot:
   ```
   python main.py
   ```

## Features

- Async data fetch from dexscreener & mevx
- Token filtering (volume, price growth, age)
- Auto-post to Telegram channel
- Flask server for uptime monitoring